package com.example.savarjisho

fun main() {
    var comp1 = Person()
    println(comp1)

}


class Person {
    var Name: String = "Tornike"
    var LastName: String = "Aduashvili"
    var Age: String = "22"
    var Email: Int = 0

    override fun toString(): String {
        return super.toString()
    }
}

